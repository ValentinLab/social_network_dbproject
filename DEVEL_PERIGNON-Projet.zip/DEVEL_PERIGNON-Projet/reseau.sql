-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost
-- Généré le :  jeu. 09 mai 2019 à 20:08
-- Version du serveur :  10.1.37-MariaDB
-- Version de PHP :  7.3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `reseau`
--

-- --------------------------------------------------------

--
-- Structure de la table `jeu`
--

CREATE TABLE `jeu` (
  `jeTitre` varchar(50) NOT NULL,
  `jeJoueur` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `jeu`
--

INSERT INTO `jeu` (`jeTitre`, `jeJoueur`) VALUES
('Breakout', 'Antoine'),
('Breakout', 'Baptiste'),
('Breakout', 'Joseph'),
('Breakout', 'Valentin'),
('Candy Crush', 'Antoine'),
('Candy Crush', 'Helene'),
('Candy Crush', 'Lucas'),
('Candy Crush', 'Medhi'),
('DrMario', 'Baptiste'),
('DrMario', 'Fabian'),
('DrMario', 'Nathanael'),
('DrMario', 'Valentin'),
('Pang', 'Fab'),
('Pang', 'Fabian'),
('Pang', 'Joseph'),
('Pang', 'Maud'),
('Pang', 'Medhi'),
('Pang', 'Nathanael'),
('Pang', 'Valentin'),
('Sokoban', 'Baptiste'),
('Sokoban', 'Fabian'),
('Sokoban', 'Helene'),
('Sokoban', 'Maud');

-- --------------------------------------------------------

--
-- Structure de la table `suivi`
--

CREATE TABLE `suivi` (
  `suSuiveur` varchar(30) NOT NULL,
  `suSuivi` varchar(30) NOT NULL,
  `suRDV` int(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `suivi`
--

INSERT INTO `suivi` (`suSuiveur`, `suSuivi`, `suRDV`) VALUES
('Fabian', 'Lucas', NULL),
('Fabian', 'Valentin', NULL),
('Helene', 'Lucas', NULL),
('Helene', 'Maud', 0),
('Joseph', 'Valentin', NULL),
('Maud', 'Fabian', NULL),
('Maud', 'Valentin', 1),
('Nathanael', 'Medhi', 0),
('Nathanael', 'Valentin', 0),
('Valentin', 'Baptiste', 0),
('Valentin', 'Lucas', NULL),
('Valentin', 'Medhi', 0);

-- --------------------------------------------------------

--
-- Structure de la table `utilisateur`
--

CREATE TABLE `utilisateur` (
  `utLogin` varchar(30) NOT NULL,
  `utPassword` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `utilisateur`
--

INSERT INTO `utilisateur` (`utLogin`, `utPassword`) VALUES
('Antoine', 'mdpA'),
('Baptiste', 'mdpB'),
('Fab', 'FabLab'),
('Fabian', 'mdpF'),
('Helene', 'mdpH'),
('Joseph', 'mdpJ'),
('Lucas', 'mdpL'),
('Maud', 'mdpM'),
('Medhi', 'mdpM'),
('Nathanael', 'mdpN'),
('Valentin', 'motDePasse');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `jeu`
--
ALTER TABLE `jeu`
  ADD PRIMARY KEY (`jeTitre`,`jeJoueur`),
  ADD KEY `fk_jeu_utilisateur` (`jeJoueur`);

--
-- Index pour la table `suivi`
--
ALTER TABLE `suivi`
  ADD PRIMARY KEY (`suSuiveur`,`suSuivi`),
  ADD KEY `fk_suivi_util` (`suSuivi`);

--
-- Index pour la table `utilisateur`
--
ALTER TABLE `utilisateur`
  ADD PRIMARY KEY (`utLogin`);

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `jeu`
--
ALTER TABLE `jeu`
  ADD CONSTRAINT `fk_jeu_utilisateur` FOREIGN KEY (`jeJoueur`) REFERENCES `utilisateur` (`utLogin`);

--
-- Contraintes pour la table `suivi`
--
ALTER TABLE `suivi`
  ADD CONSTRAINT `fk_suiveur_util` FOREIGN KEY (`suSuiveur`) REFERENCES `utilisateur` (`utLogin`),
  ADD CONSTRAINT `fk_suivi_util` FOREIGN KEY (`suSuivi`) REFERENCES `utilisateur` (`utLogin`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
